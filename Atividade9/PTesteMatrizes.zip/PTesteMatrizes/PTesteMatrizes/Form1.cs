﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PTesteMatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //ListBox.Itens.Add(" ")
        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ArrayList alunos = new ArrayList() { "Ana", "André", "Débora", "Fátima", "João", "Janete", "Otávio", "Marcelo", "Pedro", "Thais" };

            alunos.Remove("Otávio");

            string imprime = "";
            foreach (string i in alunos)
            {
                imprime += i + ", ";
            }
            MessageBox.Show(imprime);
        }

        private void btnExercicio1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar;
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i+1}° número", "Entrada de Dados");

                if (auxiliar == "")
                {
                    break;
                }
                
                if(!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Numero Inválido!");
                    i--;
                }
            }
            auxiliar = "";

            Array.Reverse(vetor);

            foreach (int i in vetor)
            {
                auxiliar += i + "\n";
            }
            MessageBox.Show(auxiliar);

        }

        private void btnExercicio3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            double nota;
            string auxiliar;

            for (int a = 0; a < 20; a++)
            {
                for (int n = 0; n < 3; n++)
                {
                    auxiliar = Interaction.InputBox($"Digite a nota {n+1}", "Notas");

                    if (!double.TryParse(auxiliar, out nota) || (nota < 0 || nota > 10))
                        MessageBox.Show("Digite um numero entre 0 e 10");

                }
            }
        }
    }
}
