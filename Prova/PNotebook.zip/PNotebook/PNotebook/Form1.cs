﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PNotebook
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            int notebook = 2;
            int numLoja = 3;
            double auxiliar;
            double media;
           //double mediaGeral;
            //string mensagem = "";

            //Criando matriz para aarmazenar as notas dos notebook
            Double[,] valores = new double[notebook, numLoja];


            //pedindo a nota dos notebook
            for (int n = 0; n < notebook; n++)
            {
                MessageBox.Show($"Notebook {n + 1}");

                for (int l = 0; l < numLoja; l++)
                {

                    string input = Interaction.InputBox($"Digite o valor da {l + 1}° loja: ");
                    //Verifica
                    if (!double.TryParse(input, out auxiliar) || auxiliar < 0)
                    {

                        MessageBox.Show("Você digitou um valor inválido ");
                        l--;
                    }
                    else
                    {
                        valores[n, l] = auxiliar;


                    }

                    Console.WriteLine();

                }


            }
            for (int n = 0; n < 2; n++)
            {
                listBoxName.Items.Add($"Notebook: {n + 1}  Loja 1:{valores[n, 0].ToString("N2")}\n   Loja 2:{valores[n, 1].ToString("N2")}\n   Loja 3: {valores[n, 2].ToString("N2")}");

            }

            for (int n = 0; n < 2; n++)
            {
                double somaDosValores = 0;
                for (int l = 0; l < 3; l++)
                {
                    somaDosValores += valores[n, l];
                }
                media = somaDosValores / numLoja;
               
                double mediaGeral = 0;
                mediaGeral += media/2;
                


                listBoxName.Items.Add($"Média Geral do Notebook{n+1}: {media.ToString("N2")}");
                //mensagem += $"A média de preço do {n + 1}° notebook é {media}\n";
                
            }
                //listBoxName.Items.Add(mediaGeral.ToString()); (FALTOU ISSO...)
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
