﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PIMC
{
    public partial class Form1 : Form
    {
        Double Altura, Peso, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtPeso.Text, out Peso) || (Peso <= 0)) {
                MessageBox.Show("Numero invalido");
                txtPeso.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja sair?", "Saida", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
                Close();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = Peso / (Altura * Altura);
            IMC = Math.Round(IMC, 1);
            txtIMC.Text = IMC.ToString();

            if (IMC < 18.5)
            {
                MessageBox.Show(IMC.ToString(), "Resultado: Magreza");
            }
            else if (IMC <= 24.9)
            {
                MessageBox.Show(IMC.ToString(),"Resultado: Normal" );
            }
            else if (IMC <= 29.9)
            {
                MessageBox.Show(IMC.ToString(), "Resultado: Sobrepeso");
            }
            else if (IMC <= 39.9)
            {
                MessageBox.Show(IMC.ToString(), "Resultado: Obesidade");
            }
            else
            {
                MessageBox.Show(IMC.ToString(), "Resultado: Obesidade Grave");
            }


        }
            private void btnLimpar_Click(object sender, EventArgs e)
            {
                txtAltura.Clear();
                txtPeso.Clear();
                txtIMC.Clear();
            }

            private void txtAltura_Validated(object sender, EventArgs e)
            {
                if (!Double.TryParse(txtAltura.Text, out Altura))
                {
                    MessageBox.Show("Numero invalido!");
                    txtAltura.Focus();
                }
            }
        
    }
}